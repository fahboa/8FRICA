$(document).ready(function() {
	$(window).on("load", function() {
			$('body').addClass('loaded');
	});
	
	
});




